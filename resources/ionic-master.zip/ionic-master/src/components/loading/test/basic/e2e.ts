
it('should open default spinner', function() {
  element(by.css('.e2eLoadingDefaultSpinner')).click();
});
