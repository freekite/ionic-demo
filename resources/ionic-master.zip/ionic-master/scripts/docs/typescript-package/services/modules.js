module.exports = function modules() {
  return {};
};
