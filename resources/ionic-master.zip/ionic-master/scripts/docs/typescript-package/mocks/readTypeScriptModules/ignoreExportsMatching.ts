export var __esModule = true;
export class OKToExport {}
export function _thisIsPrivate() {}
export var thisIsOK = '!';