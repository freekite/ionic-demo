module.exports = [
  {'name': 'advanced'},
  {'name': 'demo'},
  {'name': 'usage'},
  {'name': 'internal'}
];
